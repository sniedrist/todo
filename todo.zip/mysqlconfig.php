<?php
define(MYSQL_ENDPOINT, '');
define(MYSQL_USER, '');
define(MYSQL_PASSWORD, '');
define(MYSQL_DATABASE, '');
?>

